// Cpp program to Insert an element in an Array using class and objects.
#include<iostream>
using namespace std;

class sam
{
    public:
    int a,b,receive;
    int calnum(int a, int b)
    {
        int ret;
        ret=a+b;
        return ret;
    }
    ;
};
int main()
{
    sam obj_1;

    cout << "Take 2 inputs: "<<endl;
    cin >> obj_1.a >> obj_1.b;
    obj_1.receive=obj_1.calnum(obj_1.a, obj_1.b);
    cout << "The addition of two numbers using class and objects: " << obj_1.receive;
}